Rotational Spoon by Nguerra7 on Thingiverse: https://www.thingiverse.com/thing:1099328

Summary:
This Spoon requires the person to not spill the their food. The spoon itself does not move and always points to gravity. The handle rotates to react with gravity.